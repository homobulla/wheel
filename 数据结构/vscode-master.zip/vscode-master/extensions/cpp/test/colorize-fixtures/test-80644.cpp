struct Foo {
  Foo();
  int a;
  int b;
  int c;
};
Foo::Foo()
    : a(1),
      //     b(2),
      c(3) {}
